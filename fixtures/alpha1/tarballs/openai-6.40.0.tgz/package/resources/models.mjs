// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
import { Page } from "../core/pagination.mjs";
import { path } from "../internal/utils/path.mjs";
/**
 * List and describe the various models available in the API.
 */
export class Models extends APIResource {
    /**
     * Retrieves a model instance, providing basic information about the model such as
     * the owner and permissioning.
     */
    retrieve(model, options) {
        return this._client.get(path `/models/${model}`, { ...options, __security: { bearerAuth: true } });
    }
    /**
     * Lists the currently available models, and provides basic information about each
     * one such as the owner and availability.
     */
    list(options) {
        return this._client.getAPIList('/models', (Page), { ...options, __security: { bearerAuth: true } });
    }
    /**
     * Delete a fine-tuned model. You must have the Owner role in your organization to
     * delete a model.
     */
    delete(model, options) {
        return this._client.delete(path `/models/${model}`, { ...options, __security: { bearerAuth: true } });
    }
}
//# sourceMappingURL=models.mjs.map